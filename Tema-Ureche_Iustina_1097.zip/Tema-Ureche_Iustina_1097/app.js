const compress = (a, b = true) => {
	if ((typeof a !== 'string' && !(a instanceof String)) || typeof b !== 'boolean') {
	  throw new Error('InvalidType');
	}
  
	if (b) {
	  let compressed = '';
	  let i = 0;
  
	  while (i < a.length) {
		const char = a[i];
		let count = 1;
  
		while (i < a.length - 1 && a[i] === a[i + 1]) {
		  count++;
		  i++;
		}
  
		compressed += char + count;
		i++;
	  }
  
	  return compressed;
	} else {
	  let decompressed = '';
	  let i = 0;
  
	  while (i < a.length) {
		const char = a[i++];
		let count = '';
  
		while (i < a.length && !isNaN(parseInt(a[i]))) {
		  count += a[i++];
		}
  
		count = parseInt(count);
		if (isNaN(count)) {
		  throw new Error('Input invalid!');
		}
  
		decompressed += char.repeat(count);
	  }
  
	  return decompressed;
	}
  };
  
  module.exports = compress;