
function render(input, values){
    if (typeof input !== 'object' || typeof values !== 'object') {
        throw new Error('InvalidType');
      }
    
      const generateHTML = (obj) => {
        if (typeof obj === 'object') {
          let html = '';
          for (const key in obj) {
            const value = generateHTML(obj[key]);
            html += `<${key}>${value}</${key}>`;
          }
          return html;
        } else {
          return obj;
        }
      }
    
      let result = generateHTML(input);
    
      for (const key in values) {
        const marker = `\\$\{${key}}`;
        const regex = new RegExp(marker, 'g');
        result = result.replace(regex, values[key]);
      }
    
      return result;
 }
    


module.exports = {
    render
}