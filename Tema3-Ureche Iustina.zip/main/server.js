import app from './app.js'

app.listen(8080, () => {
    console.log('Server started on port 8080...')
})