const compress = (a, b = true) => {
	if (typeof a !== "string" && !(a instanceof String)) {
	  throw new Error("InvalidType");
	}
	if (typeof b !== "boolean") {
	  throw new Error("InvalidType");
	}
	
	if (b) {
	  let result = ""; 
	  let count = 1; 
	  for (let i = 0; i < a.length; i++) {
		
		let current = a[i];
		let next = a[i + 1];
		
		if (current === next) {
		  count++;
		} else {
		  
		  result += current + count;
		 
		  count = 1;
		}
	  }
	  return result;
	} else {
	 
	  let result = ""; 
	  for (let i = 0; i < a.length; i += 2) {
		
		let char = a[i];
		let num = parseInt(a[i + 1]);
		
		for (let j = 0; j < num; j++) {
		  result += char;
		}
	  }
	  return result;
	}
  };
  
  module.exports = compress;