import RobotList from './RobotList'

function App () {
  return (
    <div>
      <h1>
        A list of robots
      </h1>
      <RobotList />
    </div>
  ) 
}

export default App